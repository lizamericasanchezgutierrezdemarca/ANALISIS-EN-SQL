INSERT INTO ventas (fecha, producto, categoria, precio, cantidad, cliente, region, vendedor) VALUES
('2023-01-01', 'Laptop', 'Electrónica', 1200, 1, 'Carlos García', 'Lima', 'Laura'),
('2023-01-01', 'Mouse', 'Accesorios', 25, 3, 'María Torres', 'Lima', 'Juan'),
('2023-01-02', 'Escritorio', 'Muebles', 300, 1, 'Pedro Ruiz', 'Arequipa', 'Laura'),
('2023-01-02', 'Monitor', 'Electrónica', 200, 2, 'Lucía Castro', 'Lima', 'Juan'),
('2023-01-03', 'Teclado', 'Accesorios', 45, 2, 'Ana Vega', 'Cusco', 'Laura'),
('2023-01-03', 'Silla', 'Muebles', 150, 1, 'Miguel Soto', 'Arequipa', 'Juan');